<?php
// Incluir conexión
include_once("database.php");
// Obtener el id del usuario a borrar por el método GET
$id = $_GET['Id'];
// Eliminar la fila seleccionada
$result = mysqli_query($mysqli, "DELETE FROM cotizaciones WHERE Id='$id'");
// Redireccionar al inicio y desplegar que ya no existe.
header("Location:usuario.php");
?>
