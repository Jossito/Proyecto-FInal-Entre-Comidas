<?php

include_once("database.php");
?>

<?php
session_start();
if(!isset($_SESSION["user_id"]) || $_SESSION["user_id"]==null){
	print "<script>alert(\"Acceso invalido!\");window.location='login.php';</script>";
}

?>


<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <script type="text/javascript" src="JQuery.js"></script>
    <link rel="icon" href="../../../../favicon.ico">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.css" />

    <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.js"></script>

    <script>
        $(document).ready(function(){
        
        $("#tabla1").DataTable();
    });
    
    
    
    </script>
    <title>Tabla de Cotizaciones</title>

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

</head>

<body>

    <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
        <a class="navbar-brand" href="#">Entre Comidas</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
               
            </ul>
            <form class="form-inline my-2 my-lg-0">
                
               <a class="btn btn-danger" href="logout.php">Cerrar Sesión</a>
            </form>
        </div>
    </nav>

    <main role="main" class="container pt-5 mt-5">




        <div class="row col-12 justify-content-center">

            <h1 class="col-12">Cotizaciones</h1>

            <table id="tabla1" class="table col-12">
                <thead class="thead-dark">
                    <tr>
                        <th  scope="col">Producto</th>
                        <th  scope="col">Producto</th>
                        <th scope="col">Nombre y apellido</th>
                        <th scope="col">Telefono</th>
                        <th scope="col">Comentario</th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody>

                    <?php

$result = mysqli_query($mysqli, "SELECT * FROM cotizaciones ORDER BY Id DESC");
while($user_data=mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$user_data['Id']."</td>";
                echo "<td>".$user_data['Producto']."</td>";
                echo "<td>".$user_data['Nombre']."</td>";
                echo "<td>".$user_data['Telefono']."</td>";
                echo "<td>".$user_data['Comentarios']."</td>";
                
                //operaciones
                
                echo "<td><a href='delete.php?Id=$user_data[Id]' class='btn btn-danger'>Eliminar</a></td>";
                
                echo "</tr>";
                    
            }
            
        ?>


                </tbody>
            </table>







        </div>



    </main><!-- /.container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

</body>


</html>
