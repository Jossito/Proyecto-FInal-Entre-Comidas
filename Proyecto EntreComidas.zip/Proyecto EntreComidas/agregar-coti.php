    <?php
                        
                        $producto = $_POST['val1'];
                        $nombre = $_POST['val2'];
                        $telefono = $_POST['val3'];
                        $comentario = $_POST['val4'];
                        // Incluir archivo de conexión
                        include_once("database.php");
                        // Insertar usuario a base
                        $result = mysqli_query($mysqli, "INSERT INTO
                        cotizaciones(Producto,Nombre,Telefono,Comentarios) VALUES('$producto','$nombre','$telefono','$comentario')");
                        ?>