<?php

if(!empty($_POST)){
	if(isset($_POST["username"]) &&isset($_POST["password"])){
		if($_POST["username"]!=""&&$_POST["password"]!=""){
			include "database.php";
			
			$user_id=null;
			$sql1= "select * from usuarios where (Usuario=\"$_POST[username]\") and Contrasena=\"$_POST[password]\" ";
			$query = $mysqli->query($sql1);
			while ($r=$query->fetch_array()) {
				$user_id=$r["Id"];
				break;
			}
			if($user_id==null){
				print "<script>alert(\"Acceso invalido.\");window.location='login.php';</script>";
			}else{
				session_start();
				$_SESSION["user_id"]=$user_id;
				print "<script>window.location='usuario.php';</script>";				
			}
		}
	}
}



?>