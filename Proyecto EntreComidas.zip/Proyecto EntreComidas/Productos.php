<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Entre Comidas</title>

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
     <script type="text/javascript" src="JQuery.js"></script>

    <!-- Place your stylesheet here-->
    
</head>

<body>
    
    <!----Navigation bar--->

    <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
        <a class="navbar-brand" href="#">Entre Comidas</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="Index.php">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="Productos.php">Productos</a>
                </li>
               
               
            </ul>
           
        </div>
    </nav>
    
    <!----navigation bar ends--->
    
    
    <!---Slider--->
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active rounded-circle"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1" class="rounded-circle"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2" class="rounded-circle"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="img/red.png" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="img/mountains.png" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="img/snow.png" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
       <!----Slider ends--->
    <main role="main" class="container">
        
        <!--Cards--->
        
         <div class="col-12 bg-light p-5 row">
                 <div class="col-4 p-3">
                     <div class="card p-0 border-0 shadow col-12">
                    <img src="img/Bmo-Cake.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title that wraps to a new line</h5>
                        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="Producto#1">Cotizar</button>
                    </div>
                </div>
             </div>
                 
               <div class="col-4 p-3">
                     <div class="card p-0 border-0 shadow col-12">
                    <img src="img/Bmo-Cake.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title that wraps to a new line</h5>
                        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="Producto#2">Cotizar</button>
                    </div>
                </div>
             </div>
            <div class="col-4 p-3">
                     <div class="card p-0 border-0 shadow col-12">
                    <img src="img/Bmo-Cake.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title that wraps to a new line</h5>
                        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                         <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="Producto#3">Cotizar</button>
                    </div>
                </div>
             </div>
               <div class="col-4 p-3">
                     <div class="card p-0 border-0 shadow col-12">
                    <img src="img/Bmo-Cake.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title that wraps to a new line</h5>
                        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="Producto#4">Cotizar</button>
                    </div>
                </div>
             </div>
            <div class="col-4 p-3">
                     <div class="card p-0 border-0 shadow col-12">
                    <img src="img/Rick-Morty.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title that wraps to a new line</h5>
                        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="Producto#5">Cotizar</button>
                    </div>
                </div>
             </div>
               <div class="col-4 p-3">
                     <div class="card p-0 border-0 shadow col-12">
                    <img src="img/Bmo-Cake.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title that wraps to a new line</h5>
                        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                         <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="Producto#6">Cotizar</button>
                    </div>
                </div>
             </div>
                
            </div>
        
        
        
        <!---Cards end  ---->
        
        
        
        
        
       

    </main><!-- /.container -->

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

</body>
    
      
<h1 class="col-12" id="Footer" style="text-align: center; background-color: darkcyan;"> Footer ♥  </h1>

     <!---Modals----->
   

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Formulario de Cotizacion</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Producto:</label>
            <input type="text" class="form-control" id="producto" disabled>
          </div>
            <div class="form-group">
            <label for="recipient-name" class="col-form-label">Nombre y apellidos:</label>
            <input type="text" class="form-control" id="nombre">
          </div>
            <div class="form-group">
            <label for="recipient-name" class="col-form-label">Telefono:</label>
            <input type="text" class="form-control" id="telefono">
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Comentarios:</label>
            <textarea class="form-control" id="comentario"></textarea>
          </div>
            <div id="aviso-error" class="form-group d-none">
            
            
            </div>
       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button type="button" class="btn btn-primary" id="enviar-coti">Enviar</button>
      </div>
    </div>
  </div>
</div>
    
    
    <!----End Modal--->
    
    <script type="text/javascript">
    
    $('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('Formulario de Cotizacion de ' + recipient)
  modal.find('.modal-body #producto').val(recipient)
})
    
    
    
    
    
    </script>
    
    
    <!--- Validacion--->
    
    
    
    
    
    
     <script type="text/javascript">
                    $('#enviar-coti').click(function() {
                         $("#aviso-error").addClass("d-none");
                        
                        var expresionNom = /^([A-Za-zÁÉÍÓÚñáéíóúÑ]{0}?[A-Za-zÁÉÍÓÚñáéíóúÑ\']+[\s])+([A-Za-zÁÉÍÓÚñáéíóúÑ]{0}?[A-Za-zÁÉÍÓÚñáéíóúÑ\'])+[\s]?([A-Za-zÁÉÍÓÚñáéíóúÑ]{0}?[A-Za-zÁÉÍÓÚñáéíóúÑ\'])?$/;
                        
                        var resultadoNom = expresionNom.test($('#nombre').val());
                        
                        var expresionNum = /^[0-9]/;
                        
                        var resultadoNum = expresionNum.test($('#telefono').val());
                        
                        
                        if(resultadoNom == true && resultadoNum == true  && $('#comentario').val() != ""){
                             enviar($('#producto').val(), $('#nombre').val(), $('#telefono').val(), $('#comentario').val());
                        }else{
                            $("#aviso-error").removeClass("d-none");
                             $("#aviso-error").html("<p class='text-danger'>Datos incorrectos por favor verifique su informacion</p>");
                        }

                       

                    });

                    function enviar(val1, val2, val3, val4) {
                        var parametros = {
                            "val1": val1,
                            "val2": val2,
                            "val3": val3,
                            "val4": val4
                        }

                        $.ajax({

                            data: parametros,
                            url: "agregar-coti.php",
                            type: "post",
                            success: function(data) { $("#aviso-error").removeClass("d-none");
                                $("#aviso-error").html("<p class='text-success'>Cotizacion enviada</p>");
                                $('#nombre').val(""); $('#telefono').val("");
                                $('#correo').val("");
                                $('#comentario').val("");
                            }
                        });

                    }
                </script>
    
    
    
    
    
    
    
   

    
</html>