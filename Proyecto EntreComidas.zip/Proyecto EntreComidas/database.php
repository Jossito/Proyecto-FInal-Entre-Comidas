<?php

$databaseHost = "localhost";
$databaseName = "entrecomidas";
$databaseUserName = "root";
$databasePassword = "";


$mysqli = mysqli_connect($databaseHost, $databaseUserName, $databasePassword, $databaseName);

?>